<?php

dl('mongo.so');

?>
